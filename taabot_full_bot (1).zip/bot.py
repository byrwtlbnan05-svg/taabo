import aiosqlite
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, ContextTypes,
    CallbackQueryHandler, MessageHandler, filters
)

BOT_TOKEN = "8292193072:AAHxGZU1bFa3n8sGh16LCuDO7lJNoAhVomk"
ADMINS = [7055321127]

async def init_db():
    async with aiosqlite.connect("orders.db") as db:
        await db.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            order_text TEXT,
            status TEXT DEFAULT 'قيد الانتظار'
        )
        """)
        await db.commit()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📝 تقديم طلب جديد", callback_data='new_order')],
        [InlineKeyboardButton("📦 حالة الطلب", callback_data='check_order')],
        [InlineKeyboardButton("💬 الدعم الفني", url="https://t.me/zzszz")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("مرحبا بك في بوت طلباتي 💙\nاختر الخدمة التي تريدها:", reply_markup=reply_markup)

async def admin_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if user_id not in ADMINS:
        await update.message.reply_text("🚫 أنت لست مسؤولاً.")
        return
    keyboard = [[InlineKeyboardButton("عرض جميع الطلبات", callback_data="admin_view_orders")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("لوحة تحكم المسؤول:", reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    if query.data == 'new_order':
        await query.message.reply_text("اكتب طلبك الآن:")
        context.user_data['new_order'] = True
        return
    if query.data == 'check_order':
        async with aiosqlite.connect("orders.db") as db:
            cursor = await db.execute("SELECT id, order_text, status FROM orders WHERE user_id=?", (user_id,))
            rows = await cursor.fetchall()
            if not rows:
                await query.message.reply_text("لا يوجد لديك أي طلبات حالياً.")
            else:
                text = "طلباتك الحالية:\n" + "\n".join(f"{row[0]}. {row[1]} - الحالة: {row[2]}" for row in rows)
                await query.message.reply_text(text)
    if query.data == 'admin_view_orders' and user_id in ADMINS:
        async with aiosqlite.connect("orders.db") as db:
            cursor = await db.execute("SELECT id, user_id, order_text, status FROM orders")
            rows = await cursor.fetchall()
            if not rows:
                await query.message.reply_text("لا توجد طلبات حالياً.")
                return
            for row in rows:
                keyboard = [
                    [InlineKeyboardButton("قيد التنفيذ", callback_data=f"set_exec_{row[0]}")],
                    [InlineKeyboardButton("مكتمل", callback_data=f"set_done_{row[0]}")]
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                await query.message.reply_text(f"طلب رقم {row[0]}:\nالمستخدم: {row[1]}\nنص الطلب: {row[2]}\nالحالة: {row[3]}", reply_markup=reply_markup)
    if user_id in ADMINS and query.data.startswith("set_exec_"):
        order_id = int(query.data.split("_")[-1])
        await update_order_status(order_id, "قيد التنفيذ")
        await query.message.reply_text(f"تم تغيير حالة الطلب {order_id} إلى: قيد التنفيذ")
        await notify_user(order_id, "قيد التنفيذ")
    if user_id in ADMINS and query.data.startswith("set_done_"):
        order_id = int(query.data.split("_")[-1])
        await update_order_status(order_id, "مكتمل")
        await query.message.reply_text(f"تم تغيير حالة الطلب {order_id} إلى: مكتمل")
        await notify_user(order_id, "مكتمل")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if context.user_data.get('new_order'):
        text = update.message.text
        async with aiosqlite.connect("orders.db") as db:
            await db.execute("INSERT INTO orders (user_id, order_text) VALUES (?, ?)" , (user_id, text))
            await db.commit()
        await update.message.reply_text(f"✅ تم استلام طلبك:\n{text}\n📌 سيتم معالجته قريباً.")
        context.user_data['new_order'] = False

async def update_order_status(order_id, status):
    async with aiosqlite.connect("orders.db") as db:
        await db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        await db.commit()

async def notify_user(order_id, new_status):
    async with aiosqlite.connect("orders.db") as db:
        cursor = await db.execute("SELECT user_id, order_text FROM orders WHERE id=?", (order_id,))
        row = await cursor.fetchone()
        if row:
            user_id, order_text = row
            app = ApplicationBuilder().token(BOT_TOKEN).build()
            try:
                await app.bot.send_message(user_id, f"📌 تم تحديث حالة طلبك:\n{order_text}\nالحالة الجديدة: {new_status}")
            except:
                pass

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("استخدم /start للعودة للقائمة الرئيسية.\n/admindash للوصول للوحة الإدارة (للمسؤولين فقط).")


async def main():
    await init_db()
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("admindash", admin_dashboard))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    print("بوت طلباتي المتطور يعمل الآن...")
    await app.run_polling()

import asyncio
asyncio.run(main())
